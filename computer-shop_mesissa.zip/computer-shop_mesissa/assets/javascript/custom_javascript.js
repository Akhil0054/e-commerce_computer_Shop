AOS.init();







    
// =============== start swiper card ============= 
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 1, 
  spaceBetween: 30,
  pagination: {
      el: ".swiper-pagination",
      clickable: true,
  },
  autoplay: {
      delay: 3000, 
      disableOnInteraction: false,
  },
  breakpoints: {
      640: {
          slidesPerView: 1, 
          spaceBetween: 10,
      },
      768: {
          slidesPerView: 2, 
          spaceBetween: 20,
      },
      1024: {
          slidesPerView: 3, 
          spaceBetween: 30,
      },
  },
});
// =============== end swiper card ============= 


















// start top scroll button 
const scrollTopBtn = document.getElementById("scrollTopBtn");

window.onscroll = function() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    scrollTopBtn.style.display = "block";
  } else {
    scrollTopBtn.style.display = "none";
  }
};

scrollTopBtn.onclick = function() {
  window.scrollTo({ top: 0, behavior: "smooth" });
};

// end top scroll button 














